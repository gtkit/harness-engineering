[CmdletBinding()]
param(
    [string]$TargetDir
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

if ([string]::IsNullOrWhiteSpace($TargetDir)) {
    $TargetDir = Read-Host "请输入目标项目目录"
}

if ([string]::IsNullOrWhiteSpace($TargetDir)) {
    throw "目标项目目录不能为空。"
}

$PackageRoot = [System.IO.Path]::GetFullPath($PackageRoot)
$TargetDir = [System.IO.Path]::GetFullPath($TargetDir)

if ($PackageRoot -eq $TargetDir) {
    throw "目标项目目录不能和安装包目录相同。"
}

if (-not (Test-Path -LiteralPath $TargetDir)) {
    New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
}

$BackupRoot = Join-Path $TargetDir (".harness-install-backup\" + (Get-Date -Format "yyyyMMdd-HHmmss"))

$Entries = @(
    @{ Source = "AGENTS.md"; Destination = "AGENTS.md" },
    @{ Source = ".harness"; Destination = ".harness" },
    @{ Source = "doc\harness\README.md"; Destination = "doc\harness\README.md" },
    @{ Source = "openspec\changes\cpp-linux-ai-harness"; Destination = "openspec\changes\cpp-linux-ai-harness" },
    @{ Source = "docs\superpowers\plans\2026-04-13-cpp-linux-ai-harness.md"; Destination = "docs\superpowers\plans\2026-04-13-cpp-linux-ai-harness.md" }
)

function Ensure-Directory {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Backup-ExistingItem {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    $relativePath = $Path.Substring($TargetDir.Length).TrimStart('\', '/')
    $backupPath = Join-Path $BackupRoot $relativePath

    Ensure-Directory -Path (Split-Path -Parent $backupPath)
    Move-Item -LiteralPath $Path -Destination $backupPath -Force
    Write-Host "[backup] $relativePath -> $backupPath"
}

function Install-Entry {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SourceRelativePath,
        [Parameter(Mandatory = $true)]
        [string]$DestinationRelativePath
    )

    $sourcePath = Join-Path $PackageRoot $SourceRelativePath
    $destinationPath = Join-Path $TargetDir $DestinationRelativePath

    if (-not (Test-Path -LiteralPath $sourcePath)) {
        throw "安装包缺少文件或目录: $SourceRelativePath"
    }

    Backup-ExistingItem -Path $destinationPath
    Ensure-Directory -Path (Split-Path -Parent $destinationPath)

    Copy-Item -LiteralPath $sourcePath -Destination $destinationPath -Recurse -Force
    Write-Host "[install] $DestinationRelativePath"
}

Write-Host ""
Write-Host "C++ Linux AI Harness Windows 安装器"
Write-Host "安装包目录: $PackageRoot"
Write-Host "目标项目目录: $TargetDir"
Write-Host ""

foreach ($entry in $Entries) {
    Install-Entry -SourceRelativePath $entry.Source -DestinationRelativePath $entry.Destination
}

Write-Host ""
Write-Host "安装完成。"
Write-Host "如果有同名旧文件，已备份到: $BackupRoot"
Write-Host "建议下一步检查:"
Write-Host "1. $TargetDir\AGENTS.md"
Write-Host "2. $TargetDir\.harness\error-journal.md"
Write-Host "3. $TargetDir\doc\harness\README.md"
